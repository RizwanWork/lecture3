// Import the necessary modules here

export default class ProductModel {
  fetchProducts = () => {
    // Write your code here
  };
}

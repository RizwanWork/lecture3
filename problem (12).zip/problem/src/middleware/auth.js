// Please don't change the pre-written code
// Import the necessary modules here

export const auth = (req, res, next) => {
  // Write your code here
};
